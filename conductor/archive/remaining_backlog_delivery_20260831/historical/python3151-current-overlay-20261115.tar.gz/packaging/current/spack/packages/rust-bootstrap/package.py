# Copyright Spack Project Developers. See COPYRIGHT file for details.
#
# SPDX-License-Identifier: (Apache-2.0 OR MIT)
import platform
import re

from spack_repo.builtin.build_systems.generic import Package

from spack.package import (
    Executable,
    Version,
    depends_on,
    find,
    maintainers,
    run_before,
    version,
    which,
)


class RustBootstrap(Package):
    """Binary bootstrap Rust compiler."""

    homepage = "https://www.rust-lang.org"
    url = "https://static.rust-lang.org/dist/rust-1.65.0-aarch64-apple-darwin.tar.gz"

    maintainers("alecbcs", "mcmehrtens")

    tags = ["build-tools"]

    skip_version_audit = ["platform=windows"]

    # List binary rust releases for multiple operating systems and architectures.
    # These binary versions are not intended to stay up-to-date. Instead we
    # should update these binary releases as bootstrapping requirements are
    # modified by new releases of Rust.
    rust_releases = {
        "1.98.0": {
            "darwin": {
                "x86_64": "a3717fb569beab7060699dc237c90fce3d9d1efb72bec333ec8a116525100361",
                "aarch64": "5395f380bd220890b89b7e8ce137f3965cf0625b6f561af11e97c8d5c8743c3b",
            },
            "linux": {
                "x86_64": "ed8ee2df70909c88cbaf87a6cfa3920dac00b537de12a6abe6906641e0f5952f",
                "aarch64": "ac9283184301aeed06ecc9f5aa4c1be7041e18a1b197b6cb6c5d162d98f566da",
                "powerpc64le": "f126e0ecf916494d05faa694076f8d821a04b65018749a886bb71155e30dfd66",
            },
        },
        "1.96.0": {
            "darwin": {
                "x86_64": "63a6d717a5e5392ac43f0a1593e7aabe6128c8685d318cb890603b1688cb3339",
                "aarch64": "f04a974f3579d3524f6b9bc6490a27c9fb358050e7cd8a641945f30bf24c1dce",
            },
            "linux": {
                "x86_64": "c295047583a56238ea06b43f849f4b877fa12bfd4c7103f8d9a74c94c9c4e108",
                "aarch64": "371eadcca97062219cbd8593628eb5d2802bc370515d085fedce1b56b2baed57",
                "powerpc64le": "fea8e9155c69740415f1c96fa8879e61b16238e26cfee62d15f4f93aa83cb8d5",
            },
        },
        "1.95.0": {
            "darwin": {
                "x86_64": "998af750fe2c28f0dbf193edc496c9a7407850486968f40ac11a8c8adfb7cfa6",
                "aarch64": "0382ac0e7acab0daa24710701442e9fd284148b75265bdb2f59e38b60b03ac3c",
            },
            "linux": {
                "x86_64": "2e0338f18ecbaa4a0f631b9e80e8b8e26bb6fe77dd5454fba8a70cf96c1e84a1",
                "aarch64": "094c9c36531911c5cc7dd6ab2d3069ab8dcd744d6239b0bda1387b243dfc391e",
                "powerpc64le": "d301b5064ae68180ec1218b533ef0b26aaf83bba20720a0cbfdd1ad09f295133",
            },
        },
        "1.92.0": {
            "darwin": {
                "x86_64": "fc6868991e61e9262272effbb8956b23428430f5f4300c1b48eaae3969f8af2a",
                "aarch64": "235a6cca2dd4881130a9ae61ad1149bbf28bba184dd4621700f0c98c97457716",
            },
            "linux": {
                "x86_64": "6e5efd6c25953b2732d4e6b1842512536650c68cf72a8b99a0fc566012dd6ca5",
                "aarch64": "c812028423c3d7dd7ba99f66101e9e1aa3f66eab44a1285f41c363825d49dca4",
                "powerpc64le": "e2fe00a3c91f21c52947ebf96b4da016c9def5ccfedd1c335f30746db58bbf35",
            },
        },
        "1.90.0": {
            "darwin": {
                "x86_64": "3d1d24e1d4bedb421ca1a16060c21f4d803eaefba585c0b5b5d0b1e56692ef4b",
                "aarch64": "a11b52e34f5e80cb25d49f7943ae60e0b069b431727a4c09b2c890ceebee3687",
            },
            "linux": {
                "x86_64": "e453bae1c68d02fe2eae065c5452d5731308164cd154154c6ee442d2fa590685",
                "aarch64": "293f412e3412c3aa3398c78ebbdf898fa08eacad80c85a7332ce1a455504c5fc",
                "powerpc64le": "4061405099dc0aba379fe7b7a616d320272ef9325114dfa8f106c303f9b5695c",
            },
        },
        "1.88.0": {
            "darwin": {
                "x86_64": "b36b0bfac17e0a1f6cc06b9fdc4e2131ad578b4122a67792236b58650ae4c5c8",
                "aarch64": "dee921b9a41b1c3fbb088ad31dcca3b232de2cb89c268db75f40912eeaa474db",
            },
            "linux": {
                "x86_64": "ad6f0cc845e7fcca17fd451bafd2c04a7bbcb543f8f3ef5bc412fd1fef99ef7b",
                "aarch64": "dbc75abc31d142eacf15e60d0e51c4f291539974221d217b80786756b0ce1d6b",
                "powerpc64le": "e1f16b2885237695f3cce7fc2f0128a938fc07462b076cb61bd2f06e5f8baf38",
            },
        },
        "1.86.0": {
            "darwin": {
                "x86_64": "bf8121850b2f6a46566f6c2bbe9fa889b915b1039febf36853ea9d9c4256c67d",
                "aarch64": "01271f83549c3b5191334a566289aa41615ea8f8f530f49548733585f21c7e5a",
            },
            "linux": {
                "x86_64": "f6a8c0d8b8a8a737c40eee78abe286a3cbe984d96b63de9ae83443360e3264bf",
                "aarch64": "460058cd78f06875721427a42a5ce6a8b8ef2c0c3225fccfae149d9345572ff4",
                "powerpc64le": "9b104428e2b0377dbdb9dc094eb4d9f4893ada0b80d2b315f0c4ea2135ed9007",
            },
        },
        "1.85.0": {
            "darwin": {
                "x86_64": "69a36d239e38cc08c6366d1d85071847406645346c6f2d2e0dfaf64b58050d3d",
                "aarch64": "3ff45cefaf9a002069902acf3a6332113b76b530bb31803fe5cfd30f7ef8ba03",
            },
            "linux": {
                "x86_64": "be4ba7b777100c851ab268e95f70f405d28d7813ba60a9bdcf4e88c88acf8602",
                "aarch64": "0306c30bee00469fbec4b07bb04ea0308c096454354c3dc96a92b729f1c2acd1",
                "powerpc64le": "d0761bf0e1786a46dddfe60cc9397b899f680b86e6aebd7ca16b2a70a9dd631b",
            },
        },
        "1.82.0": {
            "darwin": {
                "x86_64": "b1a289cabc523f259f65116a41374ac159d72fbbf6c373bd5e545c8e835ceb6a",
                "aarch64": "49b6d36b308addcfd21ae56c94957688338ba7b8985bff57fc626c8e1b32f62c",
            },
            "linux": {
                "x86_64": "0265c08ae997c4de965048a244605fb1f24a600bbe35047b811c638b8fcf676b",
                "aarch64": "d7db04fce65b5f73282941f3f1df5893be9810af17eb7c65b2e614461fe31a48",
                "powerpc64le": "44f3a1e70be33f91927ae8d89a11843a79b8b6124d62a9ddd9030a5275ebc923",
            },
        },
        "1.81.0": {
            "darwin": {
                "x86_64": "f74d8ad24cc3cbfb825da98a08d98319565e4d18ec2c3e9503bf0a33c81ba767",
                "aarch64": "60a41dea4ae0f4006325745a6400e6fdc3e08ad3f924fac06f04c238cf23f4ec",
            },
            "linux": {
                "x86_64": "4ca7c24e573dae2f382d8d266babfddc307155e1a0a4025f3bc11db58a6cab3e",
                "aarch64": "ef4da9c1ecd56bbbb36f42793524cce3062e6a823ae22cb679a945c075c7755b",
                "powerpc64le": "bf98b27de08a2fd5a2202a2b621b02bfde2a6fde397df2a735d018aeffcdc5e2",
            },
        },
        "1.78.0": {
            "darwin": {
                "x86_64": "6c91ed3bd90253961fcb4a2991b8b22e042e2aaa9aba9f389f1e17008171d898",
                "aarch64": "3be74c31ee8dc4f1d49e2f2888228de374138eaeca1876d0c1b1a61df6023b3b",
            },
            "linux": {
                "x86_64": "1307747915e8bd925f4d5396ab2ae3d8d9c7fad564afbc358c081683d0f22e87",
                "aarch64": "131eda738cd977fff2c912e5838e8e9b9c260ecddc1247c0fe5473bf09c594af",
                "powerpc64le": "c5aedb12c552daa18072e386697205fb7b91cef1e8791fe6fb74834723851388",
            },
        },
        "1.76.0": {
            "darwin": {
                "x86_64": "7bdbe085695df8e46389115e99eda7beed37a9494f6b961b45554c658e53b8e7",
                "aarch64": "17496f15c3cb6ff73d5c36f5b54cc110f1ac31fa09521a7991c0d7ddd890dceb",
            },
            "linux": {
                "x86_64": "9d589d2036b503cc45ecc94992d616fb3deec074deb36cacc2f5c212408f7399",
                "aarch64": "2e8313421e8fb673efdf356cdfdd4bc16516f2610d4f6faa01327983104c05a0",
                "powerpc64le": "44b3494675284d26b04747a824dc974e32fd8fd46fc0aa06a7c8ebe851332d2c",
            },
        },
        "1.75.0": {
            "darwin": {
                "x86_64": "ad066e4dec7ae5948c4e7afe68e250c336a5ab3d655570bb119b3eba9cf22851",
                "aarch64": "878ecf81e059507dd2ab256f59629a4fb00171035d2a2f5638cb582d999373b1",
            },
            "linux": {
                "x86_64": "473978b6f8ff216389f9e89315211c6b683cf95a966196e7914b46e8cf0d74f6",
                "aarch64": "30828cd904fcfb47f1ac43627c7033c903889ea4aca538f53dcafbb3744a9a73",
                "powerpc64le": "2599cdfea5860b4efbceb7bca69845a96ac1c96aa50cf8261151e82280b397a0",
            },
        },
        "1.73.0": {
            "darwin": {
                "x86_64": "ece9646bb153d4bc0f7f1443989de0cbcd8989a7d0bf3b7fb9956e1223954f0c",
                "aarch64": "9c96e4c57328fb438ee2d87aa75970ce89b4426b49780ccb3c16af0d7c617cc6",
            },
            "linux": {
                "x86_64": "aa4cf0b7e66a9f5b7c623d4b340bb1ac2864a5f2c2b981f39f796245dc84f2cb",
                "aarch64": "e54d7d886ba413ae573151f668e76ea537f9a44406d3d29598269a4a536d12f6",
                "powerpc64le": "8fa215ee3e274fb64364e7084613bc570369488fa22cf5bc8e0fe6dc810fe2b9",
            },
        },
        "1.70.0": {
            "darwin": {
                "x86_64": "e5819fdbfc7f1a4d5d82cb4c3b7662250748450b45a585433bfb75648bc45547",
                "aarch64": "75cbc356a06c9b2daf6b9249febda0f0c46df2a427f7cc8467c7edbd44636e53",
            },
            "linux": {
                "x86_64": "8499c0b034dd881cd9a880c44021632422a28dc23d7a81ca0a97b04652245982",
                "aarch64": "3aa012fc4d9d5f17ca30af41f87e1c2aacdac46b51adc5213e7614797c6fd24c",
                "powerpc64le": "ba8cb5e3078b1bc7c6b27ab53cfa3af14001728db9a047d0bdf29b8f05a4db34",
            },
        },
        "1.65.0": {
            "darwin": {
                "x86_64": "139087a3937799415fd829e5a88162a69a32c23725a44457f9c96b98e4d64a7c",
                "aarch64": "7ddc335bd10fc32d3039ef36248a5d0c4865db2437c8aad20a2428a6cf41df09",
            },
            "linux": {
                "x86_64": "8f754fdd5af783fe9020978c64e414cb45f3ad0a6f44d045219bbf2210ca3cb9",
                "aarch64": "f406136010e6a1cdce3fb6573506f00d23858af49dd20a46723c3fa5257b7796",
                "powerpc64le": "3f1d0d5bb13213348dc65e373f8c412fc0a12ee55abc1c864f7e0300932fc687",
            },
        },
        "1.60.0": {
            "darwin": {
                "x86_64": "0b10dc45cddc4d2355e38cac86d71a504327cb41d41d702d4050b9847ad4258c",
                "aarch64": "b532672c278c25683ca63d78e82bae829eea1a32308e844954fb66cfe34ad222",
            },
            "linux": {
                "x86_64": "b8a4c3959367d053825e31f90a5eb86418eb0d80cacda52bfa80b078e18150d5",
                "aarch64": "99c419c2f35d4324446481c39402c7baecd7a8baed7edca9f8d6bbd33c05550c",
                "powerpc64le": "80125e90285b214c2b1f56ab86a09c8509aa17aec9d7127960a86a7008e8f7de",
            },
        },
    }

    # Normalize architectures returned by platform to those used by the
    # Rust project.
    rust_targets = {
        "aarch64": "aarch64",
        "amd64": "x86_64",
        "arm64": "aarch64",
        "powerpc64le": "powerpc64le",
        "ppc64le": "powerpc64le",
        "x86_64": "x86_64",
    }

    # Convert operating system names into the format used for Rust
    # download server.
    rust_os = {"darwin": "apple-darwin", "linux": "unknown-linux-gnu"}

    # Determine system os and architecture/target.
    os = platform.system().lower()
    target = rust_targets.get(platform.machine().lower(), platform.machine().lower())

    dated_beta = {
        "linux": {
            "aarch64": "5d4acbacde6c8c71313b0661621724be778931d6d5de1afaaba8718cbd3908e8",
            "x86_64": "f28c53c3142262b9842a4d85d5f3a2eec95cb6a32a0a9401ebb37b9ea4809497",
        },
        "darwin": {
            "aarch64": "58553a00a0df2e4374acf719279e293f15789a32aca18f86ba10b5d974f2324c",
            "x86_64": "bdf8c0714d8af3f21da4f46a520f0dcb5684bf1dbb9347deaca5e4b6fb771566",
        },
    }
    if os in dated_beta and target in dated_beta[os]:
        version("beta-2026-08-18", sha256=dated_beta[os][target])

    # Pre-release versions of the bootstrap compiler.
    # Note: These versions are unchecksumed since they will change
    # periodically as new versions are released.
    version("nightly")

    # Stable releases of the bootstrap compiler.
    # Construct releases for current system configuration.
    for release in rust_releases:
        if os in rust_releases[release] and target in rust_releases[release][os]:
            version(release, sha256=rust_releases[release][os][target])

    # rust-ldd and libLLVM both depend on zlib, which is not vendored.
    depends_on("zlib-api")
    depends_on("zlib-ng +shared", when="^[virtuals=zlib-api] zlib-ng")
    depends_on("zlib +shared", when="^[virtuals=zlib-api] zlib")
    depends_on("patchelf@0.13:", when="platform=linux", type="build")

    def url_for_version(self, version):
        if str(version) == "beta-2026-08-18":
            return f"https://static.rust-lang.org/dist/2026-08-18/rust-beta-{self.target}-{self.rust_os[self.os]}.tar.xz"
        if self.os not in ("linux", "darwin"):
            return None

        # Allow maintainers to checksum multiple architectures via
        # `spack checksum rust-bootstrap@1.70.0-darwin-aarch64`.
        match = re.search(r"(\S+)-(\S+)-(\S+)", str(version))
        if match:
            version = Version(match.group(1))
            os = self.rust_os[match.group(2)]
            target = self.rust_targets[match.group(3)]
        else:
            os = self.rust_os[self.os]
            target = self.target

        ext = "gz" if version <= Version("1.92.0") else "xz"
        url = "https://static.rust-lang.org/dist/rust-{0}-{1}-{2}.tar.{3}"
        return url.format(version, target, os, ext)

    @run_before("install", when="platform=linux")
    def fixup_rpaths(self):
        # set rpaths of libLLVM.so and rust-ldd to zlib's lib directory
        rpaths = self.spec["zlib-api"].libs.directories
        patchelf = which("patchelf", required=True)

        for binary in find(self.stage.source_path, ["libLLVM.so.*", "rust-lld"]):
            patchelf("--add-rpath", ":".join(rpaths), binary)

    def install(self, spec, prefix):
        install_script = Executable("./install.sh")
        install_args = [f"--prefix={prefix}", "--without=rust-docs"]
        install_script(" ".join(install_args))
