# Copyright Spack Project Developers. See COPYRIGHT file for details.
#
# SPDX-License-Identifier: (Apache-2.0 OR MIT)

import os
import re
import shutil
import tomllib
from typing import TYPE_CHECKING

from spack_repo.builtin.build_systems.generic import Package

from spack.package import (
    EnvironmentModifications,
    Executable,
    ProcessError,
    Spec,
    Version,
    conflicts,
    depends_on,
    join_path,
    license,
    maintainers,
    variant,
    version,
    which,
)

if TYPE_CHECKING:
    # Spack injects these executable bindings when it prepares the build module.
    from spack.package import configure, make_jobs, python


class Rust(Package):
    """The Rust programming language toolchain."""

    homepage = "https://www.rust-lang.org"
    url = "https://static.rust-lang.org/dist/rustc-1.42.0-src.tar.gz"
    git = "https://github.com/rust-lang/rust.git"

    supplier = "Organization: Rust Foundation"

    tags = ["build-tools"]

    maintainers("alecbcs", "mcmehrtens")

    license("Apache-2.0 OR MIT", checked_by="mcmehrtens")

    # When adding a version of Rust you may need to add an additional version
    # to rust-bootstrap as the minimum bootstrapping requirements increase.
    # As a general rule of thumb Rust can be built with either the previous major
    # version or the current version of the compiler as shown above.
    #
    # Pre-release versions.
    # Note: If you plan to use these versions remember to install with
    # `-n` to prevent Spack from failing due to failed checksums.
    #
    #     $ spack install -n rust@pre-release-version
    #
    version("master", branch="master", submodules=True)
    version("nightly")
    version(
        "nightly-2026-09-01",
        sha256="15bbdd27bf5d7156847cff3f843ab6dda469be1b6ee0c00b5aab8bba13fabf84",
        url="https://static.rust-lang.org/dist/2026-09-01/rustc-nightly-src.tar.xz",
    )

    # Stable versions.
    version(
        "1.99.1",
        sha256="6451598a99e77f07571960f6b21d577399d3a30f33e80cbd2e3a4aae6535d265",
    )
    version(
        "1.97.1",
        sha256="0ed06fdaffd4722a7702e0b4eebfafc897ab8f513e8e1b247cdd7e5c6df6ded2",
    )
    version(
        "1.97.0",
        sha256="de002ee301c1b7422b0a7b09d7c4cb4924cd3224e6cfb24f065dad786dd3ed12",
    )
    version(
        "1.96.1",
        sha256="77a6ff3003a4ad0cb00697b043c879e3e1a15d945b1a1f63818903bfc3fa8b98",
    )
    version(
        "1.96.0",
        sha256="b99ce16cdf0ecfc761b585ac84d131b46733465a02f8ecd0ff2de9713c62ee09",
    )
    version(
        "1.92.0",
        sha256="9e0d2ca75c7e275fdc758255bf4b03afb3d65d1543602746907c933b6901c3b8",
    )
    version(
        "1.91.0",
        sha256="327f528151753013f0a2b2c7f48955a033d718f269a4bc586314d675d0d43e8a",
    )
    version(
        "1.90.0",
        sha256="799a9f9cba4ed5351e071048bcf6b5560755d9009648def33a407dd4961f9b7e",
    )
    version(
        "1.89.0",
        sha256="2576f9f440dd99b0151bd28f59aa0ac6102d5c4f3ed4ef8a810c8dd05057250d",
    )
    version(
        "1.88.0",
        sha256="3a97544434848ae3d193d1d6bc83d6f24cb85c261ad95f955fde47ec64cfcfbe",
    )
    version(
        "1.86.0",
        sha256="022a27286df67900a044d227d9db69d4732ec3d833e4ffc259c4425ed71eed80",
    )
    version(
        "1.85.0",
        sha256="2f4f3142ffb7c8402139cfa0796e24baaac8b9fd3f96b2deec3b94b4045c6a8a",
    )
    version(
        "1.83.0",
        sha256="722d773bd4eab2d828d7dd35b59f0b017ddf9a97ee2b46c1b7f7fac5c8841c6e",
    )
    version(
        "1.81.0",
        sha256="872448febdff32e50c3c90a7e15f9bb2db131d13c588fe9071b0ed88837ccfa7",
    )
    version(
        "1.78.0",
        sha256="ff544823a5cb27f2738128577f1e7e00ee8f4c83f2a348781ae4fc355e91d5a9",
    )
    version(
        "1.76.0",
        sha256="9e5cff033a7f0d2266818982ad90e4d3e4ef8f8ee1715776c6e25073a136c021",
    )
    version(
        "1.75.0",
        sha256="5b739f45bc9d341e2d1c570d65d2375591e22c2d23ef5b8a37711a0386abc088",
    )
    version(
        "1.74.0",
        sha256="882b584bc321c5dcfe77cdaa69f277906b936255ef7808fcd5c7492925cf1049",
    )
    version(
        "1.73.0",
        sha256="96d62e6d1f2d21df7ac8acb3b9882411f9e7c7036173f7f2ede9e1f1f6b1bb3a",
    )
    version(
        "1.70.0",
        sha256="b2bfae000b7a5040e4ec4bbc50a09f21548190cb7570b0ed77358368413bd27c",
    )
    version(
        "1.65.0",
        sha256="5828bb67f677eabf8c384020582b0ce7af884e1c84389484f7f8d00dd82c0038",
    )
    version(
        "1.60.0",
        sha256="20ca826d1cf674daf8e22c4f8c4b9743af07973211c839b85839742314c838b7",
    )

    variant(
        "dev",
        default=False,
        description="Include rust developer tools like rustfmt, clippy, and rust-analyzer.",
    )
    variant("docs", default=False, description="Build Rust core documentation.")
    variant("src", default=True, description="Include standard library source files.")

    # Core dependencies
    depends_on("c", type="build")
    depends_on("cxx", type="build")

    depends_on("curl+nghttp2")
    depends_on("libgit2")
    depends_on("libssh2")
    depends_on("ninja", type="build")
    depends_on("openssl")
    depends_on("pkgconfig", type="build")
    depends_on("python@3.15.1", type="build")
    depends_on("zlib-api")

    # cmake dependency comes from LLVM. Rust has their own fork of LLVM, with tags corresponding
    # to each Rust release, so it's easy to loop through tags and grep for "cmake_minimum_required"
    depends_on("cmake@3.4.3:", type="build", when="@:1.51")
    depends_on("cmake@3.13.4:", type="build", when="@1.52:1.72")
    depends_on("cmake@3.20.0:", type="build", when="@1.73:")

    # Compiling Rust requires a previous version of Rust.
    # The easiest way to bootstrap a Rust environment is to
    # download the binary distribution of the compiler and build with that.

    # Pre-release version dependencies
    depends_on("rust-bootstrap@nightly", type="build", when="@master")
    depends_on("rust-bootstrap@nightly", type="build", when="@=nightly")
    depends_on(
        "rust-bootstrap@=beta-2026-08-18", type="build", when="@=nightly-2026-09-01"
    )

    # Stable version dependencies
    depends_on("rust-bootstrap@=1.98.0", type="build", when="@=1.99.1")
    depends_on("rust-bootstrap@1.96:1.97", type="build", when="@1.97")
    depends_on("rust-bootstrap@1.95:1.96", type="build", when="@1.96")
    depends_on("rust-bootstrap@=1.95.0", type="build", when="@=1.96.0")
    depends_on("rust-bootstrap@1.91:1.92", type="build", when="@1.92")
    depends_on("rust-bootstrap@1.90:1.91", type="build", when="@1.91")
    depends_on("rust-bootstrap@1.89:1.90", type="build", when="@1.90")
    depends_on("rust-bootstrap@1.88:1.89", type="build", when="@1.89")
    depends_on("rust-bootstrap@1.87:1.88", type="build", when="@1.88")
    depends_on("rust-bootstrap@1.85:1.86", type="build", when="@1.86")
    depends_on("rust-bootstrap@1.84:1.85", type="build", when="@1.85")
    depends_on("rust-bootstrap@1.82:1.83", type="build", when="@1.83")
    depends_on("rust-bootstrap@1.80:1.81", type="build", when="@1.81")
    depends_on("rust-bootstrap@1.77:1.78", type="build", when="@1.78")
    depends_on("rust-bootstrap@1.75:1.76", type="build", when="@1.76")
    depends_on("rust-bootstrap@1.74:1.75", type="build", when="@1.75")
    depends_on("rust-bootstrap@1.73:1.74", type="build", when="@1.74")
    depends_on("rust-bootstrap@1.72:1.73", type="build", when="@1.73")
    depends_on("rust-bootstrap@1.69:1.70", type="build", when="@1.70")
    depends_on("rust-bootstrap@1.64:1.65", type="build", when="@1.65")
    depends_on("rust-bootstrap@1.59:1.60", type="build", when="@1.60")

    # src/llvm-project/llvm/cmake/modules/CheckCompilerVersion.cmake
    conflicts("%gcc@:7.3", when="@1.73:", msg="Host GCC version must be at least 7.4")
    # https://github.com/rust-lang/llvm-project/commit/4d039a7a71899038b3bc6ed6fe5a8a48d915caa0
    conflicts("%gcc@13:", when="@:1.63", msg="Rust<1.64 not compatible with GCC>=13")
    conflicts("%intel", msg="Rust not compatible with Intel Classic compilers")
    conflicts("%oneapi", msg="Rust not compatible with Intel oneAPI compilers")

    extendable = True
    executables = [r"^rustc(-[\d.]*)?$", r"^cargo(-[\d.]*)?$"]

    phases = ["configure", "build", "install"]

    def url_for_version(self, version):
        if str(version) == "nightly-2026-09-01":
            return (
                "https://static.rust-lang.org/dist/2026-09-01/rustc-nightly-src.tar.xz"
            )
        ext = "gz" if version <= Version("1.92.0") else "xz"
        return f"https://static.rust-lang.org/dist/rustc-{version}-src.tar.{ext}"

    @classmethod
    def determine_version(cls, exe):
        output = Executable(exe)("--version", output=str, error=str)
        match = re.match(r"(rustc|cargo) (\S+)", output)
        return match.group(2) if match else None

    @classmethod
    def determine_variants(cls, exes, version_str):
        rustc_candidates = [x for x in exes if "rustc" in os.path.basename(x)]
        cargo_candidates = [x for x in exes if "cargo" in os.path.basename(x)]
        extra_attributes = {}
        if rustc_candidates:
            extra_attributes.setdefault("compilers", {})["rust"] = rustc_candidates[0]

        if cargo_candidates:
            extra_attributes["cargo"] = cargo_candidates[0]

        return "", extra_attributes

    @classmethod
    def validate_detected_spec(cls, spec, extra_attributes):
        if "cargo" not in extra_attributes:
            raise RuntimeError(f"discarding {spec} since 'cargo' is missing")

        if not extra_attributes.get("compilers", {}).get("rust"):
            raise RuntimeError(f"discarding {spec} since 'rustc' is missing")

    def setup_dependent_package(self, module, dependent_spec):
        module.cargo = Executable(os.path.join(self.spec.prefix.bin, "cargo"))

    def setup_build_environment(self, env: EnvironmentModifications) -> None:
        # Manually instruct Cargo dependency libssh2-sys to build with
        # the Spack installed libssh2 package. For more info see
        # https://github.com/alexcrichton/ssh2-rs/issues/173
        env.set("LIBSSH2_SYS_USE_PKG_CONFIG", "1")

        # Manually inject the path of ar for build.
        ar = which("ar", required=True)
        env.set("AR", ar.path)

        # Manually inject the path of openssl's certs for build
        # if certs are present on system via Spack or via external
        # openssl.
        def get_test_path(p):
            certs = join_path(p, "cert.pem")
            if os.path.exists(certs):
                return certs
            return None

        # find certs, don't set if no file is found in case
        # ca-certificates isn't installed
        certs = None
        openssl = self.spec["openssl"]
        if openssl.external:
            try:
                output = which("openssl", required=True)(
                    "version", "-d", output=str, error=str
                )
                openssl_dir = re.match('OPENSSLDIR: "([^"]+)"', output)
                if openssl_dir:
                    certs = get_test_path(openssl_dir.group(1))
            except ProcessError:
                # Continue with the selected Spack OpenSSL certificate path below.
                certs = None

        if certs is None:
            certs = get_test_path(join_path(openssl.prefix, "etc/openssl"))

        if certs is not None:
            env.set("CARGO_HTTP_CAINFO", certs)

    def setup_dependent_build_environment(
        self, env: EnvironmentModifications, dependent_spec: Spec
    ) -> None:
        env.set("CARGO_HOME", join_path(dependent_spec.package.stage.path, "cargo"))

        # Until we get a little more integration with cargo or offload solving to spack
        # (how to do this is TBD), we need it to fall back to older package versions
        # when the latest version doesn't support our rust toolchain version. This
        # option allows Spack to be slightly behind the latest rust in CI.
        #
        # This is safe as long as rust is using static libraries and there are not ABI
        # dependencies among rust packages in Spack.
        #
        # This is supported in Cargo 1.84 and higher.
        if self.spec.satisfies("@1.84:"):
            env.set("CARGO_RESOLVER_INCOMPATIBLE_RUST_VERSIONS", "fallback")

    def configure(self, spec, prefix):
        opts = []

        # Set prefix to install into spack prefix.
        opts.append(f"install.prefix={prefix}")

        # Set relative path to put system configuration files
        # under the Spack package prefix.
        opts.append("install.sysconfdir=etc")

        # Build extended suite of tools so dependent packages
        # packages can build using cargo.
        opts.append("build.extended=true")

        # Build docs if specified by the +docs variant.
        opts.append(f"build.docs={str(spec.satisfies('+docs')).lower()}")

        # Set binary locations for bootstrap rustc and cargo.
        opts.append(f"build.cargo={spec['rust-bootstrap'].prefix.bin.cargo}")
        opts.append(f"build.rustc={spec['rust-bootstrap'].prefix.bin.rustc}")

        # Disable bootstrap LLVM download.
        opts.append("llvm.download-ci-llvm=false")
        opts.append("llvm.link-jobs=1")
        if any(
            spec.satisfies(v) for v in ("@=nightly-2026-09-01", "@=1.96.0", "@=1.99.1")
        ):
            opts.append("rust.download-rustc=false")

        # Use vendored resources to perform offline build.
        opts.append("build.vendor=true")

        # Convert opts to '--set key=value' format.
        flags = [flag for opt in opts for flag in ("--set", opt)]

        # Core rust tools to install.
        tools = ["cargo"]

        # Add additional tools as directed by the package variants.
        if spec.satisfies("+dev"):
            tools.extend(["clippy", "rustdoc", "rustfmt", "rust-analyzer"])

        if spec.satisfies("+src"):
            tools.append("src")

        # Compile tools into flag for configure.
        flags.append(f"--tools={','.join(tools)}")

        # by default a `-nightly` suffix we be applied even on
        # non-nightly stable builds
        if self.spec.satisfies("@=nightly-2026-09-01"):
            flags.append("--release-channel=nightly")
        elif not self.spec.satisfies("@=nightly"):
            flags.append("--release-channel=stable")

        configure(*flags)
        receipt_dir = os.environ.get("VOIAGE_COMPILER_RECEIPTS")
        if receipt_dir:
            configuration = join_path(self.stage.source_path, "bootstrap.toml")
            with open(configuration, "rb") as stream:
                effective = tomllib.load(stream)
            if (
                effective["llvm"]["download-ci-llvm"] is not False
                or effective["llvm"]["link-jobs"] != 1
                or effective["rust"]["download-rustc"] is not False
                or effective["build"]["vendor"] is not True
            ):
                raise ValueError("Unqualified effective source compiler configuration")
            os.makedirs(receipt_dir, exist_ok=True)
            shutil.copy2(
                configuration,
                join_path(receipt_dir, f"{self.name}-{self.spec.dag_hash()}.toml"),
            )

    def build(self, spec, prefix):
        python("./x.py", "build", "--stage", "2", "-j", str(make_jobs))

    def install(self, spec, prefix):
        python("./x.py", "install", "--stage", "2", "-j", str(make_jobs))

    # known issue: https://github.com/rust-lang/rust/issues/132604
    unresolved_libraries = ["libz.so.*"]
